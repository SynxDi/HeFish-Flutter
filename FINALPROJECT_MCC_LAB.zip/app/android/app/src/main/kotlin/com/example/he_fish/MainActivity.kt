package com.example.he_fish

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
