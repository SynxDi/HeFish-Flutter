import 'package:flutter/material.dart';

var secondaryColor = Color(0xFF5593f8);
var primaryColor = Color(0xFF48c9e2);
var httpUrl = "http://10.0.2.2:8002/";
// var httpUrl = "http://192.168.18.246:8002/";

var about =
    "HE FISH is one of the biggest and largest Fish Store in the world. Established on 1998 by Henama Ea who have passions about collecting all the beautiful fish in the world.";
